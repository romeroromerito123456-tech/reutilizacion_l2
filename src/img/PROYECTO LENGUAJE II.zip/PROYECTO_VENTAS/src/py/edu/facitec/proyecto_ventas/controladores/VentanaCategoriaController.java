package py.edu.facitec.proyecto_ventas.controladores;

import py.edu.facitec.proyecto_ventas.vista.VentanaCategoria;
import py.edu.facitec.reutilizacion.interfaces.AccionesABM;

public class VentanaCategoriaController implements AccionesABM{
	private VentanaCategoria vCategoria;

	public VentanaCategoriaController(VentanaCategoria vCategoria) {
		this.vCategoria = vCategoria;
		this.vCategoria.getMiToolbar().setAcciones(this);
	}

	@Override
	public void nuevo() {
		System.out.println("Nueva Categoria");
	}

	@Override
	public void modificar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eliminar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void guardar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cancelar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void salir() {
		// TODO Auto-generated method stub
		
	}
	
	
}
