package py.edu.facitec.proyecto_ventas.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class ConnectionHelper {
	private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	static {
		setUp();
	}
	
	private static void setUp() {
		final StandardServiceRegistry serviceRegistry =
				new StandardServiceRegistryBuilder().configure().build();
		try {
			sessionFactory = new MetadataSources(serviceRegistry)
					.buildMetadata().buildSessionFactory();
		} catch (Exception e) {
			e.printStackTrace();
			StandardServiceRegistryBuilder.destroy(serviceRegistry);
		}
	}
	
//	public static void main(String[] args) {
//		System.out.println(getSessionFactory());
//	}
}
