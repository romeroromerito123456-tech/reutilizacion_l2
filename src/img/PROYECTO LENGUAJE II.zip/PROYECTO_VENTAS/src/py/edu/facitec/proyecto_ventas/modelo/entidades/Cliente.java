package py.edu.facitec.proyecto_ventas.modelo.entidades;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "clientes")
public class Cliente extends Persona{
	private LocalDate fechaRegistro;
	
	public Cliente() {
		fechaRegistro = LocalDate.now();
	}

	public LocalDate getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(LocalDate fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	
	
}
