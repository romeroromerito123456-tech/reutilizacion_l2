package py.edu.facitec.proyecto_ventas.app;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JToolBar;
import py.edu.facitec.reutilizacion.paneles.PanelFondo;
import py.edu.facitec.proyecto_ventas.vista.VentanaCliente;
import py.edu.facitec.reutilizacion.botones.MiBoton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private VentanaCliente vCliente;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		//maximizar
		setExtendedState(MAXIMIZED_BOTH);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnArchivo = new JMenu("Archivo");
		menuBar.add(mnArchivo);
		
		JMenuItem mntmCliente = new JMenuItem("Cliente");
		mntmCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				abrirRegistroCliente();
			}
		});
		mnArchivo.add(mntmCliente);
		
		JMenuItem mntmVendedor = new JMenuItem("Vendedor");
		mnArchivo.add(mntmVendedor);
		
		JMenuItem mntmCategoria = new JMenuItem("Categoria");
		mnArchivo.add(mntmCategoria);
		
		JMenuItem mntmProducto = new JMenuItem("Producto");
		mnArchivo.add(mntmProducto);
		
		JMenu mnTransacciones = new JMenu("Transacciones");
		menuBar.add(mnTransacciones);
		
		JMenuItem mntmVentas = new JMenuItem("Ventas");
		mnTransacciones.add(mntmVentas);
		
		JMenu mnReportes = new JMenu("Reportes");
		menuBar.add(mnReportes);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JToolBar toolBar = new JToolBar();
		toolBar.setOrientation(SwingConstants.VERTICAL);
		contentPane.add(toolBar, BorderLayout.WEST);

		MiBoton mbtnCliente = new MiBoton();
		mbtnCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				abrirRegistroCliente();
			}
		});
		mbtnCliente.setText("Cliente");
		toolBar.add(mbtnCliente);

		MiBoton mbtnProducto = new MiBoton();
		mbtnProducto.setText("Producto");
		toolBar.add(mbtnProducto);

		MiBoton mbtnVendedor = new MiBoton();
		mbtnVendedor.setText("Vendedor");
		toolBar.add(mbtnVendedor);

		PanelFondo panelFondo = new PanelFondo();
		panelFondo.setFondo("fondo.jpg");
		contentPane.add(panelFondo, BorderLayout.CENTER);

	}

	//abrir el panel abm
	private void abrirRegistroCliente() {
		vCliente = new VentanaCliente();
		vCliente.setUpController();
		vCliente.setVisible(true);
	}

	private void abrirRegistroProducto() {
		// TODO
	}

}
