package py.edu.facitec.proyecto_ventas.controladores;

import py.edu.facitec.proyecto_ventas.vista.VentanaCliente;
import py.edu.facitec.reutilizacion.interfaces.AccionesABM;

public class VentanaClienteController implements AccionesABM{
	
	private VentanaCliente vCliente;

	public VentanaClienteController(VentanaCliente vCliente) {
		this.vCliente = vCliente;
		this.vCliente.getMiToolbar().setAcciones(this);
	}

	@Override
	public void nuevo() {
		System.out.println("Nuevo cliente");
	}

	@Override
	public void modificar() {
		System.out.println("Modificar cliente");
	}

	@Override
	public void eliminar() {
		System.out.println("Eliminar cliente");
	}

	@Override
	public void guardar() {
		System.out.println("Guardar cliente");
	}

	@Override
	public void cancelar() {
		System.out.println("Cancelar cliente");
	}

	@Override
	public void salir() {
		vCliente.dispose();
	}
	
	
	
}
