package py.edu.facitec.proyecto_ventas.vista;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import py.edu.facitec.proyecto_ventas.controladores.VentanaCategoriaController;
import py.edu.facitec.proyecto_ventas.controladores.VentanaClienteController;
import py.edu.facitec.reutilizacion.ventanas.VentanaGenerica;

public class VentanaCategoria extends VentanaGenerica {

	private static final long serialVersionUID = 1L;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaCategoria dialog = new VentanaCategoria();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setUpController();
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	//Metodo que instancia el controlador
	public VentanaCategoriaController setUpController() {
		return new VentanaCategoriaController(this);
	}

	/**
	 * Create the dialog.
	 */
	public VentanaCategoria() {
		
		JLabel lblDescripcin = new JLabel("Descripción");
		lblDescripcin.setBounds(12, 38, 92, 17);
		getPanelFormulario().add(lblDescripcin);
		
		textField = new JTextField();
		textField.setBounds(99, 36, 305, 21);
		getPanelFormulario().add(textField);
		textField.setColumns(10);
		
	}

	@Override
	protected String getTitulo() {
		return "Registro de categorias";
	}

	@Override
	protected String getTituloFormulario() {
		return "Datos de la categoria";
	}
}
