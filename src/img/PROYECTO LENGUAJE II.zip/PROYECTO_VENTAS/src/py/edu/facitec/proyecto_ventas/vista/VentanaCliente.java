package py.edu.facitec.proyecto_ventas.vista;

import java.awt.EventQueue;

import javax.swing.JDialog;

import py.edu.facitec.proyecto_ventas.controladores.VentanaClienteController;
import py.edu.facitec.reutilizacion.ventanas.VentanaGenerica;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import com.toedter.calendar.JDateChooser;

public class VentanaCliente extends VentanaGenerica {

	private static final long serialVersionUID = 1L;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaCliente dialog = new VentanaCliente();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					//Instanciamos el controlador antes de mostrar
					dialog.setUpController();
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//Metodo que instancia el controlador
	public VentanaClienteController setUpController() {
		return new VentanaClienteController(this);
	}

	/**
	 * Create the dialog.
	 */
	public VentanaCliente() {
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNombre.setBounds(12, 34, 85, 17);
		getPanelFormulario().add(lblNombre);
		
		JLabel lblApellido = new JLabel("Apellido");
		lblApellido.setHorizontalAlignment(SwingConstants.RIGHT);
		lblApellido.setBounds(12, 75, 85, 17);
		getPanelFormulario().add(lblApellido);
		
		JLabel lblDocumento = new JLabel("Documento");
		lblDocumento.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDocumento.setBounds(12, 115, 85, 17);
		getPanelFormulario().add(lblDocumento);
		
		JLabel lblTelfono = new JLabel("Teléfono");
		lblTelfono.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTelfono.setBounds(12, 158, 85, 17);
		getPanelFormulario().add(lblTelfono);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.RIGHT);
		lblEmail.setBounds(12, 201, 85, 17);
		getPanelFormulario().add(lblEmail);
		
		JLabel lblFechaDeNacimiento = new JLabel("Fecha de Nacimiento");
		lblFechaDeNacimiento.setBounds(12, 242, 147, 17);
		getPanelFormulario().add(lblFechaDeNacimiento);
		
		JLabel lblEstado = new JLabel("Estado");
		lblEstado.setHorizontalAlignment(SwingConstants.RIGHT);
		lblEstado.setBounds(37, 284, 60, 17);
		getPanelFormulario().add(lblEstado);
		
		textField = new JTextField();
		textField.setBounds(103, 32, 301, 21);
		getPanelFormulario().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(103, 73, 301, 21);
		getPanelFormulario().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(103, 113, 114, 21);
		getPanelFormulario().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(103, 156, 114, 21);
		getPanelFormulario().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(103, 199, 301, 21);
		getPanelFormulario().add(textField_4);
		
		JCheckBox chckbxActivo = new JCheckBox("Activo");
		chckbxActivo.setBounds(103, 280, 114, 25);
		getPanelFormulario().add(chckbxActivo);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("dd/MM/yyyy");
		dateChooser.setBounds(152, 242, 138, 21);
		getPanelFormulario().add(dateChooser);
		
	}

	@Override
	protected String getTitulo() {
		return "Registro de clientes";
	}

	@Override
	protected String getTituloFormulario() {
		return "Datos del cliente";
	}
}
